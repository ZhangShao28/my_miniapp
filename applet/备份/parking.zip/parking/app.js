//app.js
var qcloud = require('./vendor/wafer-client-sdk/index.js');
var config = require('./config.js');
var checkNetWork = require("./utils/CheckNetWork.js");
var gloabalFomIds = [];
App({
  onLaunch: function (options) {
    console.log("[onLaunch] 场景值:", options.scene)
    var that = this;
      that.login();
    // 展示本地存储能力
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)

    // 登录
    // qcloud.setLoginUrl(config.service.loginUrl);
    // qcloud.login({
    //   success: function (userInfo) {
    //     console.log('登录成功', userInfo);
    //     that.globalData.userInfo = userInfo;
    //   },
    //   fail: function (err) {
    //     console.log('登录失败', err);
    //   }
    // });

    // 获取用户信息
    // wx.getSetting({
    //   success: res => {
    //     if (res.authSetting['scope.userInfo']) {
    //       // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
    //       wx.getUserInfo({
    //         success: res => {
    //           // 可以将 res 发送给后台解码出 unionId
    //           this.globalData.userInfo = res.userInfo
    //           console.log(res.userInfo)
    //           // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //           // 所以此处加入 callback 以防止这种情况
    //           if (this.userInfoReadyCallback) {
    //             this.userInfoReadyCallback(res)
    //           }
    //         }
    //       })
    //     }
    //   }
    // })

   
       var formIds = gloabalFomIds; // 获取gloabalFomIds
          if (formIds.length) {//gloabalFomIds存在的情况下 将数组转换为JSON字符串
            // formIds = JSON.stringify(formIds);
            gloabalFomIds = '';
          }
         gloabalFomIds = formIds;
        //  console.log(that.globalData.gloabalFomIds)
  },
  login:function(){
    var that = this;
    // 登录
    qcloud.setLoginUrl(config.service.loginUrl);
    qcloud.login({
      success: function (userInfo) {
        console.log('登录成功', userInfo);
        that.globalData.userInfo = userInfo;
        // wx.setStorageSync('user', userInfo)
      
        wx.getLocation({
          type: 'wgs84',
          success: function (res) {
            var latitude = res.latitude
            var longitude = res.longitude
            var speed = res.speed
            var accuracy = res.accuracy
              var val = wx.getStorageSync('loc');
              if (val!=''){
              } else {
                wx.setStorageSync('loc', res.accuracy)
                wx.reLaunch({
                  url: './index',
                })
              }
          }
        })
      },
      fail: function (err) {
        console.log('登录失败', err);
        wx.showModal({
          title: '授权提示',
          content: '停牛需要您的微信授权才能使用，点击确定去授权',
          success: function (res) {
            if (res.confirm) {
              wx.openSetting({
                success: function (res) {
                  //尝试再次登录
                  that.login();
                }
              })
            }
          }
        })
      }
    });
  },
  dealFormIds: function (formId) {
    var that = this;
    let formIds = that.globalData.gloabalFomIds;//获取全局数据中的推送码gloabalFomIds数组
    if (!formIds) formIds = [];
    let data = {
      formId: formId,
      expire: parseInt(new Date().getTime() / 1000) + 604800, //计算7天后的过期时间时间戳
      num: 1
    }
    formIds.push(data);//将data添加到数组的末尾
    that.globalData.gloabalFomIds = formIds; //保存推送码并赋值给全局变量
  },
  globalData: {
    userInfo: null,
    qcloud: qcloud,
    config: config,
    gloabalFomIds:[],
    checkNetWork: checkNetWork,
    sid:'weapp_session_F2C224D4-2BCE-4C64-AF9F-A6D872000D1A',
  }
})